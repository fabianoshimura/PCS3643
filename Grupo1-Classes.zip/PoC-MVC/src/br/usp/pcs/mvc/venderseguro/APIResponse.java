package br.usp.pcs.mvc.venderseguro;

public class APIResponse {
    private String Label;
    private String Value;

    public String getLabel() {
        return Label;
    }

    public void setLabel(String label) {
        Label = label;
    }

    public String getValue() {
        return Value;
    }

    public void setValue(String value) {
        Value = value;
    }
}